package com.bitc.dto;

import lombok.Data;

@Data
public class HighlightDto {
	private int highlightIdx;
	private String highlightTitle;
	private String highlightContents;
	private String highlightUrl;
}
